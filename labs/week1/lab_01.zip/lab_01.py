#   ASSIGNMENT:     Week 1 Lab
#   DATE:           2024-08-29
#   AUTHOR:         Marc Hauschildt